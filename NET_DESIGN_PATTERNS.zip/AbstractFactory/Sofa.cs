﻿using System;

namespace DpSession2.AbstractFactory
{
    public class Sofa : IFurniture
    {
        public void Build()
        {
            Console.WriteLine("Building a Sofa.");
        }
    }
}
