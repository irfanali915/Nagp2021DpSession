﻿namespace DpSession2.AbstractFactory
{
    public interface IFunitureFactory
    {
        IChair CreateChair();
        IFurniture CreateSofa();
        IFurniture CreateTable();
    }
}
