﻿using System;

namespace DpSession2.AbstractFactory
{
    public class Table : IFurniture
    {
        public void Build()
        {
            Console.WriteLine("Building a table.");
        }
    }
}
