﻿using System;

namespace DpSession2.AbstractFactory
{
    public class Chair : IChair
    {
        public void Build()
        {
            Console.WriteLine("Building a Chair.");
        }

        public bool HasLegs()
        {
            return true;
        }

        public bool SitOn()
        {
            return true;
        }
    }
}
