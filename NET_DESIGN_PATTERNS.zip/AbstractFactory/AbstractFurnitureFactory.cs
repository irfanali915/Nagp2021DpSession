﻿using System;

namespace DpSession2.AbstractFactory
{
    public class AbstractFurnitureFactory
    {
        public IFunitureFactory GetFurnitureFactory(string furnitureFamily)
        {
            if ("A".Equals(furnitureFamily))
            {
                return new ArtDecoFunitureFactory();
            }

            if ("M".Equals(furnitureFamily))
            {
                return new ModernFurnitureFactory();
            }

            if ("V".Equals(furnitureFamily))
            {
                return new VictorianFunitureFactory();
            }

            return null;
        }
    }
}
