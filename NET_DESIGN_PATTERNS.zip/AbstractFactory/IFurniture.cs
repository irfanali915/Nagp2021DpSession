﻿namespace DpSession2.AbstractFactory
{
    public interface IFurniture
    {
        void Build();
    }
}
