﻿namespace DpSession2.AbstractFactory
{
    public interface IChair : IFurniture
    {
        bool HasLegs();

        bool SitOn();
    }
}
