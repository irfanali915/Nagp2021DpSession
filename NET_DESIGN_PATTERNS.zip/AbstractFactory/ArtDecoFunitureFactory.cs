﻿using System;

namespace DpSession2.AbstractFactory
{
    public class ArtDecoFunitureFactory : IFunitureFactory
    {
        public IChair CreateChair()
        {
            Console.WriteLine("ArtDeco chair.");
            return new Chair();
        }

        public IFurniture CreateSofa()
        {
            Console.WriteLine("ArtDeco sofa.");
            return new Sofa();
        }

        public IFurniture CreateTable()
        {
            Console.WriteLine("ArtDeco table.");
            return new Table();
        }
    }
}
