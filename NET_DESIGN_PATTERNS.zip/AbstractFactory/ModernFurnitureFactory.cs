﻿using System;

namespace DpSession2.AbstractFactory
{
    public class ModernFurnitureFactory : IFunitureFactory
    {
        public IChair CreateChair()
        {
            Console.WriteLine("Modern chair.");
            return new Chair();
        }

        public IFurniture CreateSofa()
        {
            Console.WriteLine("Modern sofa.");
            return new Sofa();
        }

        public IFurniture CreateTable()
        {
            Console.WriteLine("Modern table.");
            return new Table();
        }
    }
}
