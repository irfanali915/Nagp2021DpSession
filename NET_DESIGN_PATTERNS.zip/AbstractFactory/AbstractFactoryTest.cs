﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DpSession2.AbstractFactory
{
    public class AbstractFactoryTest
    {
        public AbstractFactoryTest()
        {
            Console.WriteLine("Provide furniture family ( A / M / V )");
            var furnitureFamily = Console.ReadLine();
            var furniture = new AbstractFurnitureFactory().GetFurnitureFactory(furnitureFamily);

            Console.WriteLine("Provide furniture name ( C / S / T )");
            var furnitureType = Console.ReadLine();
            if ("C".Equals(furnitureType))
            {
                furniture.CreateChair();
            }

            if ("S".Equals(furnitureType))
            {
                furniture.CreateSofa();
            }

            if ("T".Equals(furnitureType))
            {
                furniture.CreateTable();
            }
        }
    }
}
