﻿using System;

namespace DpSession2.AbstractFactory
{
    public class VictorianFunitureFactory : IFunitureFactory
    {
        public IChair CreateChair()
        {
            Console.WriteLine("Victorian chair.");
            return new Chair();
        }

        public IFurniture CreateSofa()
        {
            Console.WriteLine("Victorian sofa.");
            return new Sofa();
        }

        public IFurniture CreateTable()
        {
            Console.WriteLine("Victorian table.");
            return new Table();
        }
    }
}
