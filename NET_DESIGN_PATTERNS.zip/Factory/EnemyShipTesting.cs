﻿using System;

namespace DpSession2.Factory
{
    public class EnemyShipTesting
    {
        public static void Start()
        {

            // Create the factory object
            var shipFactory = new EnemyShipFactory1();

            // Enemy ship object

            Console.WriteLine("What type of ship? (U / R / B/ U1)");

            do
            {
                var userInput = Console.ReadLine();
                var theEnemy = shipFactory.GetEnemyShip(userInput);

                if (theEnemy != null)
                {
                    DoStuffEnemy(theEnemy);
                    break;
                }
                else
                {
                    Console.WriteLine("Please enter U, R, or B next time");
                }
            } while (true);
        }

        // Executes methods of the super class

        private static void DoStuffEnemy(EnemyShip anEnemyShip)
        {
            anEnemyShip.DisplayEnemyShip();

            anEnemyShip.FollowHeroShip();

            anEnemyShip.EnemyShipShoots();
        }
    }
}
