﻿namespace DpSession2.Factory
{
    public class BigUFOEnemyShip : EnemyShip
    {
        public BigUFOEnemyShip()
        {
            Name = "Big UFO Enemy Ship";
            Damage = 40.0;
        }
    }
}
