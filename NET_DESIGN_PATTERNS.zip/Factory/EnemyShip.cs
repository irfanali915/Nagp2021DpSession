﻿using System;

namespace DpSession2.Factory
{
    public abstract class EnemyShip
    {
        public string Name { get; set; }

        public double Damage { get; set; }

        public void FollowHeroShip()
            => Console.WriteLine("{0} is following the hero", Name);

        public void DisplayEnemyShip()
            => Console.WriteLine("{0} is on the screen", Name);

        public void EnemyShipShoots()
            => Console.WriteLine("{0} attacks and does {1} damage to hero", Name, Damage);
    }
}
