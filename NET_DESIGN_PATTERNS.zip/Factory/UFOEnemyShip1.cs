﻿namespace DpSession2.Factory
{
    public class UFOEnemyShip1 : EnemyShip
    {
        public UFOEnemyShip1()
        {
            Name = "UFO Enemy Ship - 1";
            Damage = 25.0;
        }
    }
}
