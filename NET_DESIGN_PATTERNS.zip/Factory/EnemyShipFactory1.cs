﻿namespace DpSession2.Factory
{
    public class EnemyShipFactory1 : EnemyShipFactory
    {
        public new EnemyShip GetEnemyShip(string enemyShipType)
        {
            var ship = base.GetEnemyShip(enemyShipType);
            if (ship != null)
            {
                return ship;
            }

            if (enemyShipType.Equals("U1"))
            {
                return new UFOEnemyShip1();
            }

            return null;
        }
    }
}
