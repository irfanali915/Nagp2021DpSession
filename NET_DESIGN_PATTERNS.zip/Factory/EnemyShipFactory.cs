﻿namespace DpSession2.Factory
{
    public class EnemyShipFactory
    {
        public EnemyShip GetEnemyShip(string enemyShipType)
        {
            if (enemyShipType.Equals("U"))
            {
                return new UFOEnemyShip();
            }
            //if (enemyShipType.Equals("U1"))
            //{
            //    return new UFOEnemyShip1();
            //}
            if (enemyShipType.Equals("R"))
            {
                return new RocketEnemyShip();
            }
            if (enemyShipType.Equals("B"))
            {
                return new BigUFOEnemyShip();
            }
            return null;
        }
    }
}
