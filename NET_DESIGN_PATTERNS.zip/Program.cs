﻿using DpSession2.AbstractFactory;
using DpSession2.Factory;
using DpSession2.Singleton;
using System;
using System.Threading.Tasks;

namespace DpSession2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            // No Thread Safe Singleton!
            Parallel.For(1, 100, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (_) => SingletonNoTsafe.Instance.GetValue());

            // Thread Safe Singleton! with Lock
            // Performance suffers since a lock is required every time an instance is requested.
            Parallel.For(1, 100, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (_) => SingletonTsafe.Instance.GetValue());

            // Thread Safe Singleton! with Double-Check
            Parallel.For(1, 100, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (_) => SingletonTsafeDoubleCheck.Instance.GetValue());

            // Thread Safe Singleton! with No Lezy
            Parallel.For(1, 100, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (_) => SingletonTsafeNoLezy.Instance.GetValue());

            // Thread Safe Singleton! with Lezy
            Parallel.For(1, 100, new ParallelOptions { MaxDegreeOfParallelism = 6 }, (_) => SingletonTsafeLezy.Instance.GetValue());

            Console.WriteLine("{0}", string.Join(",", SingletonTsafeLezy.Instance.GetLetterList()));
            Console.WriteLine("Player1 => {0}", string.Join(",", SingletonTsafeLezy.Instance.GetTiles(7)));

            Console.WriteLine("{0}", string.Join(",", SingletonTsafeLezy.Instance.GetLetterList()));
            Console.WriteLine("Player2 => {0}", string.Join(",", SingletonTsafeLezy.Instance.GetTiles(7)));

            Console.WriteLine("{0}", string.Join(",", SingletonTsafeLezy.Instance.GetLetterList()));

            // Factory
            EnemyShipTesting.Start();

            // Abstract Factory
            new AbstractFactoryTest();
            Console.ReadLine();
        }
    }
}
