﻿using System;

namespace DpSession2.Singleton
{
    public sealed class SingletonNoTsafe
    {
        private static SingletonNoTsafe instance = null;
        private int value = 0;

        private SingletonNoTsafe()
        {

        }

        public static SingletonNoTsafe Instance
        {
            get
            {
                if (instance == null)
                {
                    Console.WriteLine("No Thread Safe Singleton!");
                    instance = new SingletonNoTsafe();
                }
                return instance;
            }
        }

        public int GetValue()
        {
            return value;
        }
    }
}
