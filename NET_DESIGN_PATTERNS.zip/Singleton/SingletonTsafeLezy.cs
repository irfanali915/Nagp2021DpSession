﻿using System;
using System.Collections.Generic;

namespace DpSession2.Singleton
{
    public sealed class SingletonTsafeLezy
    {
        private static readonly Lazy<SingletonTsafeLezy> instance = new Lazy<SingletonTsafeLezy>(() => new SingletonTsafeLezy());

        List<string> FirstInstance = new List<string> {"a", "a",
            "b", "b", "c", "c", "d", "d", "d", "d", "e", "e", "e", "e", "e",
            "e", "e", "e", "e", "e", "e", "e", "f", "f", "g", "g", "g", "h",
            "h", "i", "i", "i", "i", "j", "k", "l", "l", "l", "l", "m", "m", "n", "n", "n", "n", "o", "o",
            "o", "o", "o", "o", "o", "o", "p", "p", "q", "r", "r", "r", "r",
            "r", "r", "s", "s",  "t", "t", "u", "u", "u", "u", "v", "v", "w", "w", "x", "y", "y", "z",};

        private int value = 0;

        private SingletonTsafeLezy()
        {

        }

        public static SingletonTsafeLezy Instance => instance.Value;

        public int GetValue()
        {
            return value;
        }

        public List<String> GetLetterList()
        {
            return FirstInstance;
        }

        public List<String> GetTiles(int howManyTiles)
        {
            // Tiles to be returned to the user
            List<String> tilesToSend = new List<String>();

            // Cycle through the LinkedList while adding the starting
            // Strings to the to be returned LinkedList while deleting
            // them from letterList

            var random = new Random();
            for (int i = 0; i <= howManyTiles; i++)
            {
                var randomVal = random.Next(0, FirstInstance.Count);
                tilesToSend.Add(FirstInstance[randomVal]);
                FirstInstance.RemoveAt(randomVal);
            }

            // Return the number of letter tiles requested
            return tilesToSend;
        }
    }
}
