﻿using System;

namespace DpSession2.Singleton
{
    public sealed class SingletonTsafeDoubleCheck
    {
        private static SingletonTsafeDoubleCheck instance = null;
        private int value = 0;

        private static readonly object temp = new object();

        private SingletonTsafeDoubleCheck()
        {

        }

        public static SingletonTsafeDoubleCheck Instance
        {
            get
            {
                if (instance == null)
                {
                    lock (temp)
                    {
                        if (instance == null)
                        {
                            Console.WriteLine("Thread Safe Singleton! with Double-Check");
                            instance = new SingletonTsafeDoubleCheck();
                        }
                    }
                }
                return instance;
            }
        }

        public int GetValue()
        {
            return value;
        }
    }
}
