﻿using System;

namespace DpSession2.Singleton
{
    public sealed class SingletonTsafe
    {
        private static SingletonTsafe instance = null;
        private int value = 0;

        private static readonly object temp = new object();

        private SingletonTsafe()
        {

        }

        public static SingletonTsafe Instance
        {
            get
            {
                lock (temp)
                {
                    if (instance == null)
                    {
                        Console.WriteLine("Thread Safe Singleton!");
                        instance = new SingletonTsafe();
                    }
                    return instance;
                }
            }
        }

        public int GetValue()
        {
            return value;
        }
    }
}
