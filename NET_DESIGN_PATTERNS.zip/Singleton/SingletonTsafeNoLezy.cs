﻿using System;

namespace DpSession2.Singleton
{
    public sealed class SingletonTsafeNoLezy
    {
        private static readonly SingletonTsafeNoLezy instance = new SingletonTsafeNoLezy();
        private int value = 0;

        private SingletonTsafeNoLezy()
        {

        }

        public static SingletonTsafeNoLezy Instance => instance;

        public int GetValue()
        {
            return value;
        }
    }
}
