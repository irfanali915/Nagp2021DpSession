package com.training.abstractFactory.designPattern.nagp.products.impl;

import com.training.abstractFactory.designPattern.nagp.products.Chair;

public class ModrenChair implements Chair {

	@Override
	public String hasLegs() {
		// TODO Auto-generated method stub
		return "Modern chair has 4 legs.";
	}

	@Override
	public String sitOn() {
		// TODO Auto-generated method stub
		return "I am siting on Modern chair.";
	}

}
