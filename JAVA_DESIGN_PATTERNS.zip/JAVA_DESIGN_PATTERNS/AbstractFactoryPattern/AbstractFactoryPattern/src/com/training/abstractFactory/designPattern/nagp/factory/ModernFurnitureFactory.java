package com.training.abstractFactory.designPattern.nagp.factory;

import com.training.abstractFactory.designPattern.nagp.products.Chair;
import com.training.abstractFactory.designPattern.nagp.products.impl.ModrenChair;

public class ModernFurnitureFactory implements FurnitureAbstractFactory {

	@Override
	public Chair createChair() {
		// TODO Auto-generated method stub
		ModrenChair ch = new ModrenChair();
		return ch;
	}

}
