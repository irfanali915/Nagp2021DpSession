package com.training.abstractFactory.designPattern.nagp.test;

import com.training.abstractFactory.designPattern.nagp.factory.FurnitureFactory;
import com.training.abstractFactory.designPattern.nagp.factory.ModernFurnitureFactory;
import com.training.abstractFactory.designPattern.nagp.factory.VictorianFunitureFactory;
import com.training.abstractFactory.designPattern.nagp.products.Chair;

public class TestDesignPattern {

	public static void main(String[] args) {
		testAbstractFactory();
	}

	private static void testAbstractFactory() {
		Chair modernChair = FurnitureFactory.getChair(new ModernFurnitureFactory());  
		Chair  victorianChair = FurnitureFactory.getChair(new VictorianFunitureFactory());
		System.out.println("AbstractFactory ModernChair Config::-----"+modernChair.sitOn());
		System.out.println("AbstractFactory VictorianChair Config::----"+victorianChair.sitOn());
	}

}
