package com.training.abstractFactory.designPattern.nagp.factory;

import com.training.abstractFactory.designPattern.nagp.products.Chair;

public interface FurnitureAbstractFactory {

	public Chair createChair();

}
