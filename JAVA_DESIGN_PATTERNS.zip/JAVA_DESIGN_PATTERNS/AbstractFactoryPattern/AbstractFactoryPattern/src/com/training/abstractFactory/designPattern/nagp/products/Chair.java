package com.training.abstractFactory.designPattern.nagp.products;

public interface Chair {

	public String hasLegs();
	public String sitOn();
}
