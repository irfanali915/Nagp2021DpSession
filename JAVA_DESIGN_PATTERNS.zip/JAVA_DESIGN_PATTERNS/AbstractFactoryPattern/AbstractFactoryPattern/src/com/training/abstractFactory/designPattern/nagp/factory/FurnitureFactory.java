package com.training.abstractFactory.designPattern.nagp.factory;

import com.training.abstractFactory.designPattern.nagp.products.Chair;

public class FurnitureFactory {
	
	public static Chair getChair(FurnitureAbstractFactory factory){
		return factory.createChair();
	}

}
