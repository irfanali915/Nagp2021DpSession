package com.training.abstractFactory.designPattern.nagp.products.impl;

import com.training.abstractFactory.designPattern.nagp.products.Chair;

public class VictorianChair implements Chair {

	@Override
	public String hasLegs() {
		// TODO Auto-generated method stub
		return "Victorian Chair has 4 legs.";
	}

	@Override
	public String sitOn() {
		// TODO Auto-generated method stub
		return "I am siting on Victorian Chair.";
	}

}
