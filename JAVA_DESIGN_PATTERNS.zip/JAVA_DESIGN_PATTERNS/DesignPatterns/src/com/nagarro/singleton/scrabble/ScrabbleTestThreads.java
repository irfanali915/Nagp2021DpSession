package com.nagarro.singleton.scrabble;

public class ScrabbleTestThreads {

	public static void main(String[] args) {

		// Create a new Thread created using the Runnable interface

		Runnable getTiles = new GetTheTiles();

		Runnable getTilesAgain = new GetTheTiles();

		// Call for the code in the method run to execute

		Thread t1 = new Thread(getTiles);
		t1.setName("Chandler Bing");
		Thread t2 = new Thread(getTilesAgain);
		t2.setName("Joey Tribianni");
		t1.start();
		t2.start();

	}

}