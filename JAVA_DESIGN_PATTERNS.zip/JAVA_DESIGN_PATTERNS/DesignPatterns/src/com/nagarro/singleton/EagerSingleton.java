package com.nagarro.singleton;

public class EagerSingleton {

	private static final EagerSingleton singletonObject = new EagerSingleton();

	private EagerSingleton() {
		
	}

	public static EagerSingleton getInstance() {
		return singletonObject;
	}

}
