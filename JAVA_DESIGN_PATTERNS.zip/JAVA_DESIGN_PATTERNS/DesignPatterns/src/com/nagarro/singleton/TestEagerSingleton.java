package com.nagarro.singleton;

public class TestEagerSingleton {
	
	public static void main(String[] args) {
		EagerSingleton object = EagerSingleton.getInstance();
		
		EagerSingleton newobject = EagerSingleton.getInstance();
		
		System.out.println(object.hashCode());
		System.out.println(newobject.hashCode());
	}

}
