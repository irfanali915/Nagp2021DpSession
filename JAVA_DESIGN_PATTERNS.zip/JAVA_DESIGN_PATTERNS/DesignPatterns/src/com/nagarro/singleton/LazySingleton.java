package com.nagarro.singleton;

public class LazySingleton {

	private static LazySingleton instance;

	private LazySingleton() {
		// private constructor
	}

	// method to return instance of class
	public static LazySingleton getInstance() {
		if (instance == null) {
			// if instance is null, initialize
			instance = new LazySingleton();
		}
		return instance;
	}

}
