package com.nagarro.singleton;

public class TestLazySingleton {

	public static void main(String[] args) {
		
		LazySingleton object = LazySingleton.getInstance();

		LazySingleton newobject = LazySingleton.getInstance();

		System.out.println(object.hashCode());
		System.out.println(newobject.hashCode());
	}

}
