package com.nagarro.singleton.Threads;

public class ThreadCall implements Runnable {

	public void run() {

		ThreadSafeSingleton newInstance = ThreadSafeSingleton.getInstance();

		System.out.println(
				Thread.currentThread().getName() + "   " + "Instance ID: " + System.identityHashCode(newInstance));

	}

}
