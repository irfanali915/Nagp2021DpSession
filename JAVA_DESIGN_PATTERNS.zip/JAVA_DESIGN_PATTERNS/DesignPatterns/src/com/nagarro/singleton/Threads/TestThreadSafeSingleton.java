package com.nagarro.singleton.Threads;

public class TestThreadSafeSingleton {

	public static void main(String[] args) {

		// Create a new Thread created using the Runnable interface

		Runnable testThread1 = new ThreadCall();

		Runnable testThread2 = new ThreadCall();

		// Call for the code in the method run to execute

		Thread t1 = new Thread(testThread1);
		t1.setName("testThread1");
		Thread t2 = new Thread(testThread2);
		t2.setName("testThread2");
		t1.start();
		t2.start();

	}
}
